import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    todos: [
      { id: 1, text: 'Изучить Vuex', completed: false },
      { id: 2, text: 'Сделать проект', completed: false },
      { id: 3, text: 'Пройти курс до конца', completed: true }
    ]
  },
  mutations: {
    ADD_TODO(state, text) {
      state.todos.push({
        id: Date.now(),
        text,
        completed: false
      })
    },
    REMOVE_TODO(state, id) {
      state.todos = state.todos.filter(todo => todo.id !== id)
    },
    TOGGLE_TODO(state, id) {
      const todo = state.todos.find(t => t.id === id)
      if (todo) todo.completed = !todo.completed
    }
  },
  actions: {
    addTodoAsync({ commit }, text) {
      setTimeout(() => {
        commit('ADD_TODO', text)
      }, 300)
    }
  },
  getters: {
    allTodos: state => state.todos,
    completedTodos: state => state.todos.filter(t => t.completed),
    totalCount: state => state.todos.length,
    completedCount: (state, getters) => getters.completedTodos.length
  }
})