<template>
  <div class="todo-form">
    <input
      v-model="text"
      @keyup.enter="add"
      placeholder="Что нужно сделать?"
      type="text"
    />
    <button @click="add">Добавить</button>
  </div>
</template>

<script>
export default {
  name: 'AddTodo',
  data() {
    return {
      text: ''
    }
  },
  methods: {
    add() {
      const value = this.text.trim()
      if (!value) return
      // Прямая мутация (как в уроке)
      this.$store.commit('ADD_TODO', value)
      // Если хотите продемонстрировать действие — раскомментируйте:
      // this.$store.dispatch('addTodoAsync', value)
      this.text = ''
    }
  }
}
</script>

<style scoped>
.todo-form {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
}
.todo-form input {
  flex: 1;
  padding: 10px 15px;
  border: 2px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
}
.todo-form input:focus {
  border-color: #42b983;
  outline: none;
}
.todo-form button {
  background: #42b983;
  border: none;
  color: white;
  padding: 10px 20px;
  border-radius: 8px;
  font-weight: bold;
  cursor: pointer;
}
</style>