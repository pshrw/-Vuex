<template>
  <ul class="todo-list">
    <TodoItem
      v-for="todo in todos"
      :key="todo.id"
      :todo="todo"
    />
  </ul>
</template>

<script>
import { mapGetters } from 'vuex'
import TodoItem from './TodoItem.vue'

export default {
  name: 'TodoList',
  components: { TodoItem },
  computed: {
    ...mapGetters({
      todos: 'allTodos'
    })
  }
}
</script>

<style scoped>
.todo-list {
  list-style: none;
}
</style>