<template>
  <div class="stats">
    <span>Всего: {{ total }}</span>
    <span>Выполнено: {{ completed }}</span>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  name: 'TodoStats',
  computed: {
    ...mapGetters({
      total: 'totalCount',
      completed: 'completedCount'
    })
  }
}
</script>

<style scoped>
.stats {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
  font-weight: 500;
  color: #555;
}
</style>