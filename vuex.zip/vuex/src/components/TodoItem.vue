<template>
  <li class="todo-item" :class="{ completed: todo.completed }">
    <span @click="toggle">{{ todo.text }}</span>
    <button @click="remove">Удалить</button>
  </li>
</template>

<script>
export default {
  name: 'TodoItem',
  props: {
    todo: {
      type: Object,
      required: true
    }
  },
  methods: {
    toggle() {
      this.$store.commit('TOGGLE_TODO', this.todo.id)
    },
    remove() {
      this.$store.commit('REMOVE_TODO', this.todo.id)
    }
  }
}
</script>

<style scoped>
.todo-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #f9f9f9;
  border: 1px solid #eee;
  border-radius: 8px;
  padding: 12px 15px;
  margin-bottom: 10px;
}
.todo-item.completed span {
  text-decoration: line-through;
  opacity: 0.6;
}
.todo-item span {
  cursor: pointer;
  flex: 1;
}
.todo-item button {
  background: #e74c3c;
  border: none;
  color: white;
  padding: 5px 12px;
  border-radius: 6px;
  cursor: pointer;
}
</style>