<template>
  <div id="app">
    <h1>Список задач</h1>
    <TodoStats />
    <AddTodo />
    <TodoList />
  </div>
</template>

<script>
import TodoStats from './components/TodoStats.vue'
import AddTodo from './components/AddTodo.vue'
import TodoList from './components/TodoList.vue'

export default {
  name: 'App',
  components: {
    TodoStats,
    AddTodo,
    TodoList
  }
}
</script>

<style>
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background: #f4f4f4;
  display: flex;
  justify-content: center;
  padding: 40px 20px;
  min-height: 100vh;
}
#app {
  width: 100%;
  max-width: 500px;
  background: white;
  border-radius: 12px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
  padding: 30px;
}
h1 {
  color: #2c3e50;
  margin-bottom: 20px;
  font-size: 2rem;
}
</style>